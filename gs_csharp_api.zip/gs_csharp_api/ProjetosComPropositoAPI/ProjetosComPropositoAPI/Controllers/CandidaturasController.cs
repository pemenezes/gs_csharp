﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProjetosComPropositoAPI.Data;
using ProjetosComPropositoAPI.Models;

namespace ProjetosComPropositoAPI.Controllers
{
    [Route("api/v1/Candidaturas")]
    [ApiController]
    public class CandidaturasController : ControllerBase
    {
        private readonly AppDbContext _context;

        public CandidaturasController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Candidaturas
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Candidatura>>> GetCandidaturas()
        {
            return await _context.Candidaturas.ToListAsync();
        }

        // GET: api/Candidaturas/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Candidatura>> GetCandidatura(int id)
        {
            var candidatura = await _context.Candidaturas.FindAsync(id);

            if (candidatura == null)
            {
                return NotFound();
            }

            return candidatura;
        }

        // PUT: api/Candidaturas/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCandidatura(int id, Candidatura candidatura)
        {
            if (id != candidatura.Id)
            {
                return BadRequest();
            }

            _context.Entry(candidatura).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CandidaturaExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Candidaturas
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Candidatura>> PostCandidatura(Candidatura candidatura)
        {
            _context.Candidaturas.Add(candidatura);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCandidatura", new { id = candidatura.Id }, candidatura);
        }

        // DELETE: api/Candidaturas/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCandidatura(int id)
        {
            var candidatura = await _context.Candidaturas.FindAsync(id);
            if (candidatura == null)
            {
                return NotFound();
            }

            _context.Candidaturas.Remove(candidatura);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool CandidaturaExists(int id)
        {
            return _context.Candidaturas.Any(e => e.Id == id);
        }
    }
}
