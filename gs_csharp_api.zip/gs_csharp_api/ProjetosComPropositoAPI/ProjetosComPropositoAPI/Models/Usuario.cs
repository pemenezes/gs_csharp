﻿namespace ProjetosComPropositoAPI.Models
{
    public class Usuario
    {
        public Usuario()
        {
            Candidaturas = new HashSet<Candidatura>();
        }

        public int Id { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Especialidade { get; set; }

        public virtual ICollection<Candidatura> Candidaturas { get; set; }
    }
}