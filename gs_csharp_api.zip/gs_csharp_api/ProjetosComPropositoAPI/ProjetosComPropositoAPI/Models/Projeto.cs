﻿namespace ProjetosComPropositoAPI.Models
{
    public class Projeto
    {
        public Projeto()
        {
            Candidaturas = new HashSet<Candidatura>();
        }

        public int Id { get; set; }
        public string Titulo { get; set; }
        public string Descricao { get; set; }
        public string ODS_Alinhada { get; set; }

        public virtual ICollection<Candidatura> Candidaturas { get; set; }
    }
}