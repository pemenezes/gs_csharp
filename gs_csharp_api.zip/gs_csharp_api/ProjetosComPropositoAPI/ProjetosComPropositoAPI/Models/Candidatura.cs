﻿namespace ProjetosComPropositoAPI.Models
{
    public class Candidatura
    {
        public int Id { get; set; }
        public string Status { get; set; }

        public int UsuarioId { get; set; }
        public int ProjetoId { get; set; }

        public virtual Usuario? Usuario { get; set; }
        public virtual Projeto? Projeto { get; set; }
    }
}