﻿using ProjetosComPropositoAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace ProjetosComPropositoAPI.Data
{
    public class AppDbContext : DbContext
    {
        // O construtor passa as opções de configuração (nossa string de conexão) 
        // para a classe base "DbContext"
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        // Mapeamento das nossas classes para tabelas no banco de dados
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Projeto> Projetos { get; set; }
        public DbSet<Candidatura> Candidaturas { get; set; }
    }
}